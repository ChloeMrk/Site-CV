<?php include("inc/header.inc.php");?>
<?php include("inc/nav.inc.php");?>

<?php 

   
    if(!empty($_POST)){

     

        $requeteSQL ="INSERT INTO experience (emplois, duree, nom_entreprise, description_emplois) VALUES ('$_POST[emplois]', '$_POST[duree]', '$_POST[nom_entreprise]','$_POST[description_emplois]')";
        $result = $pdo->exec($requeteSQL);
        echo $result;
        
    }

    

    



    
?>

<?php 

            $result = $pdo->query("SELECT * FROM experience WHERE delection_flag = 0");
            while($experience = $result->fetch(PDO::FETCH_OBJ)){?>
              <div class="resume-item d-flex flex-column flex-md-row justify-content-between">
                <div class="resume-content">
                  <h3 class="mb-0" name="job"> <?php echo $experience->emplois ;?> </h3>
                  <div class="subheading mb-3" name="societe"> <?php echo $experience->nom_entreprise ; ?></div>
                  <p name="description"> <?php echo $experience->description_emplois ;?> </p>
                </div>
                <div class="resume-date text-md-right">
                  <span class="text-primary" name="date"> <?php echo $experience->duree ;?></span>
                </div>
                <a href="modif.inc.php"> <button type="submit" class="btn btn-warning">Modifier</button> </a>
                
                <button type="submit" class="btn btn-warning">Supprimer</button>
               
              </div>
            
    <?php } ?>

<div class="starter-template">  
    <form method="POST" action="" enctype='multipart/form-data'>

        <div class="form-group">
            <label for="emplois">Nom de l'emplois</label>
            <input type="texte" class="form-control" id="emplois" name="emplois">
        </div>

       
        <div class="form-group">
            <label for="duree">Durée</label>
            <input type="texte" class="form-control" id="duree" name="duree">
        </div>

        <div class="form-group">
            <label for="nom_entreprise">Nom de l'entreprise</label>
            <input type="texte" class="form-control" id="nom_entreprise" name="nom_entreprise">
        </div>


       
        <div class="form-group">
            <label for="description_emplois">Description de l'emplois</label>
            <textarea rows="10" class="form-control" id="description_emplois" name="description_emplois"> </textarea>
        </div>

       

        <a href="modif.inc.php"> <button type="submit" class="btn btn-warning">Modifier</button> </a>

        <button type="submit" class="btn btn-primary">Enregistrer</button>

    </form>
</div>

</form>
<div class="container-fluid p-0">

<?php $pdo = new PDO("mysql:host=localhost;dbname=cv","root","",array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION)); ?>

  <section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="about">
    <div class="w-100">
    <?php $result = $pdo->query("SELECT * FROM info WHERE prenom = 'chloe'");
          $p = $result->fetch(PDO::FETCH_OBJ); ?>
    <h1 class="mb-0">
        <?php echo $p->prenom;?>

        <?php $result = $pdo->query("SELECT * FROM info WHERE nom = 'merck'");
        $n = $result->fetch(PDO::FETCH_OBJ);?>
        <span class="text-primary"><?php echo $n->nom; ?></span>
      </h1>


      <div class="subheading mb-5"><?php $result = $pdo->query("SELECT * FROM info WHERE adresse = '52 BOULEVARD CIRCULAIRE VILLEPINTE'");
          $a = $result->fetch(PDO::FETCH_OBJ);
          $result = $pdo->query("SELECT * FROM info WHERE cp = '93420'");
          $cp= $result->fetch(PDO::FETCH_OBJ);?>

          <?php echo $a->adresse . " " .$cp->cp; ?>
        <a href="mailto:name@email.com"><?php $result = $pdo->query("SELECT * FROM info WHERE email = 'chloe.merck@ynov.com'");
        $email = $result->fetch(PDO::FETCH_OBJ);?>
        <?php echo $email->email;?></a>
        
      </div>
      <p class="lead mb-5">I am experienced in leveraging agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition.</p>
      <div class="social-icons">
        <a href="#">
          <i class="fab fa-linkedin-in"></i>
        </a>
        <a href="#">
          <i class="fab fa-github"></i>
        </a>
        <a href="#">
          <i class="fab fa-twitter"></i>
        </a>
        <a href="#">
          <i class="fab fa-facebook-f"></i>
        </a>
      </div>
    </div>
  </section>

  <hr class="m-0">
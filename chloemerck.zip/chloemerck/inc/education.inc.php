<hr class="m-0">

<section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="education">
  <div class="w-100">
    <h2 class="mb-5">Education</h2>

   
    <?php 
      
      $result = $pdo->query("SELECT * FROM formation WHERE delection_flag = 0");
      while($formation = $result->fetch(PDO::FETCH_OBJ)){?>
    <div class="resume-item d-flex flex-column flex-md-row justify-content-between">
      <div class="resume-content">
        <h3 class="mb-0" name="nom_ecole" id="nom_ecole"><?php echo $formation->nom_ecole ?></h3>
        <div class="subheading mb-3" name="diplome" id="diplome"><?php echo  $formation->diplome ?></div>
        <p name ="specialite" id = "specialite"><?php echo $formation->specialite?></p>
      </div>
      <div class="resume-date text-md-right">
        <span class="text-primary" name="temps_formation" id="temps_formation"><?php echo $formation->temps_formation?></span>
      </div>
    </div>

  

      <?php }?>
</section>

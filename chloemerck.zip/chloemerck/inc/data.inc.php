<?php 

    require_once("./obj/experience.class.php");

    $pdo = new PDO("mysql:host=localhost;dbname=cv","root","",array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION)); 

?>


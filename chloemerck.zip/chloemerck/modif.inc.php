<?php include("inc/header.inc.php");?>


<?php

if(isset($_POST["modifier"])){
       $requete = "UPDATE experience SET emplois = '$_POST[emplois]', duree = '$_POST[duree], nom_entreprise ='$_POST[nom_entreprise]', description_emplois = '$_POST[description_emplois] WHERE id_emplois = $_POST[id_emplois]'";
       $resultat=$pdo->exec($requete);
    }

if(isset($_POST["supprimer"])){
    $pdo->exec("DELETE FROM experience WHERE id_emplois = '$_POST[id_emplois]'");
        echo $result . ' donnée(s) affectée(s) par la requête DELETE<br>';
}

    
?>

<?php 

            $result = $pdo->query("SELECT * FROM experience WHERE delection_flag = 0");
            while($experience = $result->fetch(PDO::FETCH_OBJ)){?>
              <div class="resume-item d-flex flex-column flex-md-row justify-content-between">
                <div class="resume-content">
                  <h3 class="mb-0" name="job"> <?php echo $experience->emplois ;?> </h3>
                  <div class="subheading mb-3" name="societe"> <?php echo $experience->nom_entreprise ; ?></div>
                  <p name="description"> <?php echo $experience->description_emplois ;?> </p>
                </div>
                <div class="resume-date text-md-right">
                  <span class="text-primary" name="date"> <?php echo $experience->duree ;?></span>
                </div>

                <a href=""> <button type="submit" class="btn btn-warning" onclick = >Changer donnée</button> </a>
                <a href=""> <button name = "modifier" type="submit" class="btn btn-warning">Modifier</button> </a>
                <a href=""><button name="supprimer" type="submit" class="btn btn-warning">Supprimer</button></a>
                
               
              </div>
            
    <?php } ?>



